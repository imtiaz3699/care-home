import React from 'react'

function Body() {
  return (
    <div className='bg-green-800'>
      <div className=''>
        <div className='flex flex-col items-center'>
            <div>Our Homes</div>
            <div>Our Homes are designed to be a "home from home" in every sense, with delightful surroundings, beautifully furnished rooms, excellent food and, most importantly, a standard of care which is second to none.</div>
        </div>
        <img></img>
      </div>
    </div>
  )
}

export default Body
