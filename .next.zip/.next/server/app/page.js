(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 8387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9546)), "C:\\Users\\User\\Desktop\\Imtiaz-Ahmed\\care-home\\src\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4053)), "C:\\Users\\User\\Desktop\\Imtiaz-Ahmed\\care-home\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\User\\Desktop\\Imtiaz-Ahmed\\care-home\\src\\app\\page.tsx"];

    

    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/page","pathname":"/","bundlePath":"app/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 3014:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23))

/***/ }),

/***/ 3279:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4566));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1366));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8954))

/***/ }),

/***/ 1366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HeroSection_HeroSection)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(2797);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.css
var swiper = __webpack_require__(3754);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination.css
var pagination = __webpack_require__(3141);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(1987);
;// CONCATENATED MODULE: ./src/app/components/footer/Footer.tsx


function Footer() {
    const footer1 = [
        {
            name: "About Us",
            url: ""
        },
        {
            name: "Our Philosophy",
            url: ""
        },
        {
            name: "History",
            url: ""
        },
        {
            name: "Testimonials",
            url: ""
        }
    ];
    const houseAddress = [
        {
            name: "Ashby Lodge wakefield",
            url: ""
        },
        {
            name: "Ashfield House, Conventry",
            url: ""
        },
        {
            name: "As Care Leicester",
            url: ""
        },
        {
            name: "Ashview House, Stoke-on-Trent",
            url: ""
        },
        {
            name: "Old Vicarage Workshop",
            url: ""
        },
        {
            name: "Ashton Court Rotherham",
            url: ""
        },
        {
            name: "Aston Manor Dewsbury",
            url: ""
        },
        {
            name: "Ashford House Liecestershire",
            url: ""
        },
        {
            name: "London Road Specialist Nursing Home,Leicester",
            url: ""
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "footer flex flex-col items-center text-center md:text-left md:flex-row bg-green-800 justify-center gap-20 py-10 px-3",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-center text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/logo.png",
                            alt: "",
                            className: "w-[200px] h-[200px] m-0"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-white",
                            children: "SBH Healthcare Limited"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-white",
                            children: [
                                "311 Brookvale Road ",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " Erdington Birmingham B23 7RR"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-white font-bold text-[35px]",
                            children: "SBH Healthcare"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col gap-1",
                            children: footer1.map((element, idx)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hover:underline cursor-pointer text-white",
                                    children: element.name
                                });
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-white font-bold text-[35px]",
                            children: "Contact Us"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-white",
                            children: "Tel:07482112058"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-white",
                            children: "Email:contact@mauricare.com"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-white font-normal text-[35px]",
                                    children: "Follow Us"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/facebook.png",
                                            alt: "",
                                            className: "w-[50px] h-[50px]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/twitter.png",
                                            alt: "",
                                            className: "w-[50px] h-[50px]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/linked.png",
                                            alt: "",
                                            className: "w-[50px] h-[50px]"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const footer_Footer = (Footer);

;// CONCATENATED MODULE: ./src/app/components/HeroSection/HeroSection.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Import Swiper React components

// Import Swiper styles

// Import Swiper React components
// Import Swiper styles


// import required modules


function HeroSection() {
    const images = [
        "/oldAge.jpg",
        "/oldAge2.jpg",
        "/oldAge3.jpg"
    ];
    const houseAddress = [
        {
            name: "Ashby Lodge wakefield",
            url: ""
        },
        {
            name: "Ashfield House, Conventry",
            url: ""
        },
        {
            name: "As Care Leicester",
            url: ""
        },
        {
            name: "Ashview House, Stoke-on-Trent",
            url: ""
        },
        {
            name: "Old Vicarage Workshop",
            url: ""
        },
        {
            name: "Ashton Court Rotherham",
            url: ""
        },
        {
            name: "Aston Manor Dewsbury",
            url: ""
        },
        {
            name: "Ashford House Liecestershire",
            url: ""
        },
        {
            name: "London Road Specialist Nursing Home,Leicester",
            url: ""
        }
    ];
    const ourServices = [
        {
            img: "/dementia.webp",
            name: "Dementia Care"
        },
        {
            img: "/nursing-care.webp",
            name: "Nursing Care"
        },
        {
            img: "physical-disabilities.webp",
            name: "Physical Disabilities"
        },
        {
            img: "respite-care.webp",
            name: "Respite Care"
        }
    ];
    const footer1 = [
        {
            name: "About Us",
            url: ""
        },
        {
            name: "Our Philosophy",
            url: ""
        },
        {
            name: "History",
            url: ""
        },
        {
            name: "Testimonials",
            url: ""
        }
    ];
    const testimonials = [
        {
            name: "Emily Truner",
            review: "A haven of warmth and care. The staff at this old age home go above and beyond to make each resident feel cherished and valued. I m so grateful for the compassionate environment they provide"
        },
        {
            name: "George Anderson",
            review: "A true blessing for our seniors. The facilities are top-notch, and the organized activities keep everyone engaged and lively. This old age home sets a shining example for others."
        },
        {
            name: "Margaret Hughes",
            review: "Home away from home. The staffs dedication is heartwarming. They ensure that our loved ones are not just cared for, but they flourish with genuine affection."
        },
        {
            name: "William Parker",
            review: "Exceptional support for seniors needs. This old age homes commitment to providing personalized attention is commendable. Our family is at peace knowing our relative is in such capable hands."
        },
        {
            name: "Lily Foster",
            review: "A treasure for the elderly. The cheerful atmosphere and the constant companionship make it a joyous community. Its evident that the staff here are driven by a deep passion for caregiving."
        },
        {
            name: "Samuel Wright",
            review: "A place of respect and honor for seniors. The old age homes commitment to maintaining residents dignity while offering top-quality care is truly inspiring."
        },
        {
            name: " Olivia Patel",
            review: "An old age home that feels like family. The warm and friendly ambiance, along with the well-planned recreational activities, creates an environment where seniors can thrive."
        },
        {
            name: "Henry Carter",
            review: "Exceptional attention to detail. The staffs unwavering dedication to meeting each residents unique needs sets this old age home apart. Our family is deeply appreciative."
        },
        {
            name: "Amelia Turner",
            review: "A haven of tranquility for our loved ones. The picturesque surroundings combined with the staffs genuine care provide a safe and peaceful retreat for seniors."
        },
        {
            name: "Charles Hughes",
            review: "A remarkable establishment. The commitment to fostering an environment of companionship and vitality is truly commendable. Our dear ones are in the best hands here."
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full md:h-[700px]",
                children: /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* Swiper */.tq, {
                    className: "mySwiper w-full h-full relative",
                    children: images.map((element, idx)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                            className: "w-full h-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: element,
                                alt: "",
                                className: "w-full h-full bg-cover"
                            })
                        }, idx);
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center py-20 gap-5 lg:gap-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-[25px] sm:text-[35px] text-center font-bold text-blue-800",
                        children: "What sets us Apart"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col-reverse lg:flex-row px-3 sm:px-0 items-center gap-2 lg:gap-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-full sm:w-[500px] sm:h-[400px] drop-shadow-2xl border-4 border-blue-800 rounded-xl shadow-slate-800",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/careworkout.webp",
                                    alt: "",
                                    className: "w-full h-full   rounded-lg"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col w-full sm:w-[500px] lg:w-[450px] gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "font-bold text-[20px] gap-3 text-blue-800",
                                        children: "Personalized Care:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Within our establishment, we hold a steadfast belief in the distinct and individual needs of each resident. To address this, our approach involves meticulously tailored care plans that prioritize personal preferences and requirements. Our dedicated team is committed to ensuring that every resident receives the attentive and specialized care they merit. This personalized approach extends beyond medical necessities, encompassing a resident's unique hobbies, interests, and background. By upholding this philosophy, we create an environment where every individual is valued and their well-being is at the forefront of our care."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col lg:flex-row items-center px-3 sm:px-0 gap-2 lg:gap-10 mt-0 lg:mt-20",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col  w-full sm:w-[500px] lg:w-[450px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "font-bold text-[20px] text-blue-800",
                                        children: "Engaging Activities:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Life at SBH is a tapestry of vitality and connection. Our diverse activities, from arts to fitness and outings, keep residents engaged and joyful. These thoughtfully curated experiences foster creativity and holistic well-being. Beyond our walls, captivating outings offer a window to the world. Within our community, friendships flourish, creating a vibrant and supportive atmosphere. As the day ends, residents retire content, embodying the enriching power of genuine human connections."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-full sm:w-[500px] sm:h-[400px] drop-shadow-2xl border-4 border-blue-800 rounded-xl shadow-slate-800",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/engage.jpg",
                                    alt: "",
                                    className: "w-full h-full bg-cover rounded-lg"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col-reverse lg:flex-row px-3 sm:px-0 items-center gap-2 lg:gap-10 mt-0 lg:mt-20",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-full sm:w-[500px] sm:h-[400px] drop-shadow-2xl border-4 border-blue-800 rounded-xl shadow-slate-800",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/dining.jpg",
                                    alt: "",
                                    className: "w-full h-full   rounded-lg"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col w-full sm:w-[500px] lg:w-[450px] gap-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "font-bold text-[20px] gap-3 text-blue-800",
                                        children: "Delicious Dining:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "At our esteemed old age home, we recognize the pivotal role of nourishment in well-being. Accomplished chefs curate nutritious and delectable meals, tailored to diverse dietary needs, ensuring that each dining moment is a source of joy. Our culinary experts blend health and flavor seamlessly, crafting a variety of dishes that cater to individual preferences. Beyond sustenance, we view dining as a cherished experience, fostering both communal connections and personal comfort. With a commitment to excellence, we prioritize the residents' dietary requirements while elevating their culinary journey."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col lg:flex-row items-center px-3 sm:px-0 gap-2 lg:gap-10 mt-0 lg:mt-20",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col w-full sm:w-[500px] lg:w-[450px] gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "font-bold text-[20px] text-blue-800",
                                        children: "Safe and Secure:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "At the heart of our commitment lies the utmost importance placed on the safety and security of our residents. Our modern facility boasts a range of cutting-edge safety features, seamlessly integrated to provide a secure living space. Complemented by our dedicated and compassionate staff, who are accessible round-the-clock, we ensure a serene and protected environment that promotes a high quality of life. From advanced surveillance systems to secure access protocols, every detail is meticulously designed to safeguard our residents' well-being."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-full sm:w-[500px] sm:h-[400px] drop-shadow-2xl border-4 border-blue-800 rounded-xl shadow-slate-800",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/elderly-patients.jpg",
                                    alt: "",
                                    className: "w-full h-full bg-cover rounded-lg"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center text-center gap-5 md:flex-row md:justify-between w-full px-4 md:px-12 bg-white py-8 md:py-12 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "font-bold text-[25px] md:text-[35px]",
                        children: "Quality Care Your Loved Ones Deserve"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-green-800 p-2 md:p-5 rounded-xl font-bold text-[15px]",
                        children: [
                            "Call Us Today: ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "07916789486"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center justify-center py-5 bg-green-800",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[20px] md:text-[30px] font-bold text-green-500 text-center",
                        children: "Our Care Services"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[16px] md:text-[20px] px-3 md:px-0 md:w-[50%] text-center ",
                        children: '"We collaborate intimately with our residents, their cherished ones, and every invested party to ensure that we provide unwavering assistance for individuals to reside with us as integral members of our extended kinship."'
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "px-3 grid grid-cols-2 md:flex md:flex-row items-center justify-between gap-3 md:gap-20 py-10",
                        children: ourServices.map((element, idx)=>{
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " flex flex-col items-center gap-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: element.img,
                                        alt: "",
                                        className: "w-[70px] h-[70px] md:w-[100px] md:h-[100px]"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-green-500 text-center text-[16px]",
                                        children: element.name
                                    })
                                ]
                            }, idx);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-col items-center py-5 px-3 md:py-10 md:px-20",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-center gap-3 md:gap-5 justify-center  text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "font-bold text-green-500 text-[20px] md:text-[30px] ",
                            children: "Make an Inquiry"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "font-semibold text-green-500  text-[18px] md:text-[25]",
                            children: "We would love to hear from if you you're a resident or a relative."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:w-[700px] text-gray-500 text-[16px] md:text-[20px]",
                            children: "''Our transparent and approachable leadership group encourages staff, residents, and family members to openly express any apprehensions or suggestions. To directly reach our central administration, kindly utilize the provided form. Regarding internal inquiries about our care home, please get in touch with the specific facility.''"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row items-center justify-center px-3 md:px-10 py-10 md:gap-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center justify-center w-full  md:w-[500px] border border-green-500 rounded-xl gap-5 px-5 md:px-10 py-10",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-1 md:gap-3 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "name",
                                        className: "text-[16px] md:text-[20px]",
                                        children: "Your Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        className: "w-full h-[30px] rounded-lg outline-none border border-gray-500 "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-1 md:gap-3 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "email",
                                        className: "text-[16px] md:text-[20px]",
                                        children: "Your Email Address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        className: "w-full h-[30px] rounded-lg outline-none border border-gray-500 "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-1 md:gap-3 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "telephone",
                                        className: "text-[16px] md:text-[20px]",
                                        children: "Telephone Number (Optional)"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        className: "w-full h-[30px] rounded-lg outline-none border border-gray-500 "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-1 md:gap-3 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "",
                                        className: "text-[16px] md:text-[20px]",
                                        children: "What would you like to discuss?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        name: "",
                                        id: "",
                                        cols: 30,
                                        rows: 10,
                                        className: "outline-none border border-gray-500"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "bg-green-800 px-3 py-3 rounded-xl text-white",
                                children: "Send Inquiry"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-2 hidden gap-5 md:flex flex-col md:gap-5 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "border border-gray-500 w-[300px] h-[250px] rounded-xl",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/care.jpg",
                                    alt: "",
                                    className: "w-full h-full bg-cover rounded-xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "border border-gray-500 w-[300px] h-[300px] rounded-xl",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/care2.jpg",
                                    alt: "",
                                    className: "w-full h-full  bg-cover rounded-xl"
                                })
                            })
                        ]
                    })
                ]
            }),
            "b",
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center xl:flex-row justify-center gap-10 xl:gap-20  bg-green-800 pb-5 xl:pb-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full xl:w-[60%] xl:h-[500px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/design.jpg",
                            alt: "",
                            className: "bg-cover w-full h-full"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center justify-center w-full xl:w-[40%] px-3 xl:px-0 xl:pr-10 text-center xl:text-left",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "font-bold text-white text-[25px] xl:text-[30px]",
                                children: "Our Philosophy"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-[18px]",
                                children: "At our care home, families can trust that their loved ones are in a safe, nurturing, and homely environment. We prioritize dignity, respect, and happiness for each resident, valuing their unique identities. Our dedicated team fosters a warm and supportive atmosphere, encouraging independence and engagement in fulfilling activities. Open communication with staff, residents, and families is vital to us, as we continuously improve our services. Safety is paramount, and our well-trained staff ensures a secure environment. Regular social events strengthen our close-knit community. Our care home is a place of comfort, love, and joy, where residents thrive and families are always welcomed."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center justify-center py-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center gap-2 pb-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "font-bold text-green-500 text-[20px] md:text-[30px] text-center",
                                children: "What Residents and Families Says"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " text-[18px] md:text-[20px] text-center",
                                children: [
                                    "Here are some of our latest reviews from CareHome.co.uk,",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " the leading care home review web site."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-row gap-20 items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* Swiper */.tq, {
                            freeMode: true,
                            spaceBetween: 20,
                            pagination: {
                                clickable: true
                            },
                            modules: [
                                modules/* FreeMode */.Rv,
                                modules/* Pagination */.tl
                            ],
                            className: "mySwiper w-[300px] sm:w-[400px]  md:w-[700px]  lg:w-[900px] h-[300px] px-5 gap-10",
                            breakpoints: {
                                640: {
                                    slidesPerView: 1,
                                    spaceBetween: 30
                                },
                                768: {
                                    slidesPerView: 2,
                                    spaceBetween: 10
                                },
                                1024: {
                                    slidesPerView: 3,
                                    spaceBetween: 30
                                }
                            },
                            style: {
                                paddingRight: "40px",
                                paddingLeft: "40px",
                                paddingTop: "20px",
                                paddingBottom: "20px"
                            },
                            children: testimonials.map((element, idx)=>{
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(swiper_react/* SwiperSlide */.o5, {
                                    style: {
                                        margin: 0
                                    },
                                    className: "text-white py-20 flex flex-col w-[300px] sm:w-[400px] gap-3 h-[500px] items-center justify-center text-center rounded-xl px-3 py-5  bg-green-800 ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "",
                                            children: element.review
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "font-bold text-[20px] ",
                                            children: element.name
                                        })
                                    ]
                                }, idx);
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {})
        ]
    });
}
/* harmony default export */ const HeroSection_HeroSection = (HeroSection);


/***/ }),

/***/ 8954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const CookieConsent = ()=>{
    const [showBanner, setShowBanner] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const consent = localStorage.getItem("cookieConsent");
        if (!consent) {
            setShowBanner(true);
        }
    }, []);
    const handleConsent = ()=>{
        localStorage.setItem("cookieConsent", "true");
        setShowBanner(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: showBanner && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "absolute top-[65px] md:top-[85px] left-0 right-0 w-full z-10 mx-auto bg-green-800 py-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-white p-4 text-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This website uses cookies to improve your experience."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "mt-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded",
                        onClick: handleConsent,
                        children: "Accept"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CookieConsent);


/***/ }),

/***/ 9546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./src/app/components/Navbar.tsx
var Navbar = __webpack_require__(6363);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/app/components/HeroSection/HeroSection.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\User\Desktop\Imtiaz-Ahmed\care-home\src\app\components\HeroSection\HeroSection.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const HeroSection = (__default__);
;// CONCATENATED MODULE: ./src/app/components/cookie-consent/CookieConsent.tsx

const CookieConsent_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\User\Desktop\Imtiaz-Ahmed\care-home\src\app\components\cookie-consent\CookieConsent.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: CookieConsent_esModule, $$typeof: CookieConsent_$$typeof } = CookieConsent_proxy;
const CookieConsent_default_ = CookieConsent_proxy.default;


/* harmony default export */ const CookieConsent = (CookieConsent_default_);
;// CONCATENATED MODULE: ./src/app/page.tsx




function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HeroSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(CookieConsent, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [697,178,615,23], () => (__webpack_exec__(8387)));
module.exports = __webpack_exports__;

})();